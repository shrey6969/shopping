import Header from "./Header";
import Products from "./Product";
import { useState } from "react";
import CartList from "./CartList";
function App() {
const [product, setproduct] = useState([
{
url:'imgs/lenovo.png',
name: 'lenovo ideapad Slim 3',
price: 57000
},
{
url: 'imgs/watch.png',
name: 'fastrack w98',
price: 1500
},
])
const [cart, setCart] = useState([])
const [showCart, setShowCart] = useState(false)
const addToCart = (data) => {
setCart([...cart, { ...data, quantity: 1 }])
}
const handleShow = (value) => {
setShowCart(value)
}
return (
<div >
<Header count={cart.length} handleShow={handleShow} />
{
showCart ?
<CartList cart={cart} /> :
<Products product={product} addToCart={addToCart} />
}
</div>
)
}
export default App;